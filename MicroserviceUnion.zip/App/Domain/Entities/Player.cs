﻿namespace $safeprojectname$.Domain.Entities
{
    public class Player
    {
        public int Id { get; set; }

        public string Name { get; set; }
    }
}
