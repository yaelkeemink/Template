﻿
namespace $safeprojectname$.Infrastructure
{
    public class Program
    {
        public static void Main(string[] Args)
        {
            // Empty program for entity framework
        }
    }
}
